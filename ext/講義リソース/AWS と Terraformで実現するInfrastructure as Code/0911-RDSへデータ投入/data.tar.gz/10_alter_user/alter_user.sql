ALTER USER 'admin'@'%' IDENTIFIED WITH mysql_native_password BY 'Passw0rd';
