var appconfig = require("./config/app.config.js");
var dbconfig = require("./config/mysql.config.js");
var path = require("path");
var accesslogger = require("./lib/log/accesslogger.js");
var systemlogger = require("./lib/log/systemlogger.js");
var accountcontrol = require("./lib/security/accountcontrol.js");
var express = require("express");
var favicon = require("serve-favicon");
var bodyParser = require("body-parser");
var cookieParser = require("cookie-parser");
var session = require("express-session");
var MySqlStore = require("express-mysql-session")(session);
var flash = require("connect-flash");
var app = express();

// Express settings
app.set("view engine", "ejs");
app.disable("x-powered-by");

// Expose global method to view engine.
app.use((req, res, next) => {
  res.locals.moment = require("moment");
  res.locals.padding = require("./lib/math/math.js").padding;
  next();
});

// Static resource rooting.
app.use(favicon(path.join(__dirname, "/public", "/favicon.ico")));
app.use("/public", express.static(path.join(__dirname, "/public")));
app.use("/help", express.static(path.join(__dirname, "/help")));
app.use("/health", require("./routes/health.js"));

// Set access log.
app.use(accesslogger());

// Set middleware.
app.use(cookieParser());
app.use(session({
  store: new MySqlStore({
    host: dbconfig.HOST,
    port: dbconfig.PORT,
    user: dbconfig.USERNAME,
    password: dbconfig.PASSWORD,
    database: dbconfig.DATABASE
  }),
  secret: appconfig.security.SESSION_SECRET,
  resave: false,
  saveUninitialized: true,
  name: "sid"
}));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(flash());
app.use(...accountcontrol.initialize());

// Dynamic resource rooting.
app.use("/", (() => {
  var router = express.Router();
  router.use((req, res, next) => {
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    next();
  });
  router.use("/search/", require("./routes/search.js"));
  router.use("/shop/", require("./routes/shop.js"));
  router.use("/account/", require("./routes/account.js"));
  router.use("/", require("./routes/index.js"));
  return router;
})());

// Set system log.
app.use(systemlogger());

app.listen(appconfig.PORT);