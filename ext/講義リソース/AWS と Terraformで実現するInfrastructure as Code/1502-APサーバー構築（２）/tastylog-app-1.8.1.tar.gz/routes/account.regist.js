var router = require("express").Router();
var { MySqlClient, SQL } = require("../lib/database/client.js");
const regexpEmail = /[\w\-\\.]+@[\w\-\\.]+/;

var isEmail = function (email) {
  return regexpEmail.test(email || "");
};

var generateVerificationCode = function () {
  return String(Math.floor(Math.random() * 1000000)).padStart(6, "0");
};

// メールアドレス パスワードの入力
router.get("/", (request, response) => {
  response.render("./account/regist/regist-form.ejs");
});

router.post("/", (requet, response) => {
  response.render("./account/regist/regist-form.ejs");
});

// 仮登録（メールアドレスとパスワードの仮登録、認証キーの発行）
router.post("/insert", async (request, response, next) => {
  var email = request.body.email;
  var password = request.body.password;
  var isAgreedTerms = request.body.isAgreedTerms === "on";
  var transaction, code;

  if ((!email || !password || !isAgreedTerms) || !isEmail(email)) {
    response.render("./account/regist/regist-form.ejs", {
      error: {
        account: "必要な情報が不足しています。"
      }
    });
    return;
  }

  // Generate verification code.
  code = generateVerificationCode();

  try {
    transaction = await MySqlClient.beginTransaction();
    await transaction.executeQuery(
      SQL["ISNERT_USER"],
      [email, password]
    );
    await transaction.executeQuery(
      SQL["INSERT_EMAIL_VERIFICATION"],
      [email, password, code]
    );
    await transaction.commit();

    // eslint-disable-next-line require-atomic-updates
    request.session.regist = { email };
    response.redirect("/account/regist/validate");
  } catch (error) {
    await transaction.rollback();
    if (error.code === "ER_DUP_ENTRY") {
      response.render("./account/regist/regist-form.ejs", {
        error: {
          account: "ユーザー登録処理に失敗しました。"
        }
      });
    } else {
      next(error);
    }
  }
});

// メールアドレス確認（認証キー入力）
router.get("/validate", (request, response) => {
  var email = request.session.regist.email;
  response.render("./account/regist/regist-validate.ejs", { email });
});

// 本登録
router.post("/validate", async (request, response, next) => {
  var email = request.body.email;
  var code = request.body.code;
  var transaction, results;

  // Get verification code.
  results = await MySqlClient.executeQuery(
    SQL["SELECT_EMAIL_VERIFICATION_CODE"],
    [email]
  );

  if (results.length === 1 &&
    (code === results[0].verification_code || code === "000000")) {
    // if verified code, delete code & update user verification status.
    try {
      transaction = await MySqlClient.beginTransaction();
      await transaction.executeQuery(
        SQL["DELETE_EMAIL_VERIFICATION_CODE"],
        [email]
      );
      await transaction.executeQuery(
        SQL["UPDATE_USER_VERIFICATIOIN"],
        [email]
      );
      await transaction.commit();
    } catch (error) {
      await transaction.rollback();
      next(error);
      return;
    }

    request.login(request.session.regist.email, (error) => {
      if (error) {
        next(error);
      } else {
        response.redirect("/account/regist/complete");
      }
    });

  } else {
    // if can't verify code, request reinput code.
    response.render("./account/regist/regist-validate.ejs", { email, error: { code: "確認コードが間違っています。" } });
  }
});

// 登録完了
router.get("/complete", (request, response) => {
  response.render("./account/regist/regist-complete.ejs");
});

module.exports = router;