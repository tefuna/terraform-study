var router = require("express").Router();
var { MySqlClient, SQL } = require("../lib/database/client.js");

router.get("/", async (request, response) => {
  var email = request.user.email;

  var data = (await MySqlClient.executeQuery(
    SQL["SELECT_USER_BY_EMAIL"],
    [email]
  ))[0];

  data.SUCCESS_PROFILE = (request.flash("SUCCESS_PROFILE") || [])[0];
  data.ERROR_PASSWORD = (request.flash("ERROR_PASSWORD") || [])[0];
  data.SUCCESS_PASSWORD = (request.flash("SUCCESS_PASSWORD") || [])[0];
  data.ERROR_DELETE = (request.flash("ERROR_DELETE") || [])[0];

  response.render("./account/settings/index.ejs", data);
});

router.post("/profile", async (request, response) => {
  var email = request.user.email;
  var name = request.body.name;
  var description = request.body.description;

  await MySqlClient.executeQuery(
    SQL["UPDATE_USER_PROFILE"],
    [name, description, email]
  );

  request.flash("SUCCESS_PROFILE", "プロフィールを更新しました。");
  response.redirect("/account/settings/");
});

router.post("/email", async (request, response) => {
  var email = request.user.email;
  var data;

  data = (await MySqlClient.executeQuery(
    SQL["SELECT_USER_BY_EMAIL"],
    [email]
  ))[0];

  response.render("./account/settings/index.ejs", data);
});

router.post("/password", async (request, response) => {
  var email = request.user.email;
  var { old_password, new_password, new_password_confirm } = request.body;
  var data;

  // 現在の情報を取得
  data = (await MySqlClient.executeQuery(
    SQL["SELECT_USER_BY_EMAIL"],
    [email]
  ))[0];

  // 古いパスワードが一致しているか
  if (old_password !== data.password) {
    request.flash("ERROR_PASSWORD", "旧パスワードが間違っています。");
    response.redirect("/account/settings/");
    return;
  }

  // 新しいパスワードと確認が一致しているか
  if (new_password !== new_password_confirm) {
    request.flash("ERROR_PASSWORD", "新しいパスワードが一致していません。");
    response.redirect("/account/settings/");
    return;
  }

  // 新しいパスワードに更新
  await MySqlClient.executeQuery(
    SQL["UPDATE_USER_PASSWORD"],
    [new_password, email]
  );

  request.flash("SUCCESS_PASSWORD", "新しいパスワードに更新しました。");
  response.redirect("/account/settings/");
});

router.post("/delete", async (request, response) => {
  var email = request.user.email;
  var isAgreed = request.body.isAgreed;

  if (isAgreed !== "on") {
    request.flash("ERROR_DELETE", "アカウント削除するためには注意事項の確認が必要です。");
    response.redirect("/account/settings/");
    return;
  }
  
  await MySqlClient.executeQuery(
    SQL["DELETE_USER"],
    [email]
  );

  request.logout();

  response.redirect("/account/seeyou");
});

module.exports = router;