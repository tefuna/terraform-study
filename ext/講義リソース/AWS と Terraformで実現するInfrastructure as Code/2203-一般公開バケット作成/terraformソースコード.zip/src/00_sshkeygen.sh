#!/bin/bash

ssh-keygen -t rsa -b 2048 -f tastylog-dev-keypair

